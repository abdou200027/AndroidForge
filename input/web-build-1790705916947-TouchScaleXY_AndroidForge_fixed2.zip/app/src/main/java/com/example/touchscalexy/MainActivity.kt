
package com.example.touchscalexy

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import com.google.android.material.slider.Slider
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var xValue: TextView
    private lateinit var yValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 50, 40, 40)
        }

        val title = TextView(this).apply {
            text = "TouchScale X/Y"
            textSize = 28f
            setTextColor(Color.WHITE)
        }
        val subtitle = TextView(this).apply {
            text = "Independent touch scaling • Shizuku"
            textSize = 15f
        }

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 35, 0, 25)
        }

        xValue = TextView(this)
        yValue = TextView(this)

        val xSlider = Slider(this).apply {
            valueFrom = 50f
            valueTo = 200f
            value = 100f
            stepSize = 1f
        }
        val ySlider = Slider(this).apply {
            valueFrom = 50f
            valueTo = 200f
            value = 100f
            stepSize = 1f
        }

        xSlider.addOnChangeListener { _, value, _ ->
            xValue.text = "X Sensitivity: ${value.toInt()}%"
        }
        ySlider.addOnChangeListener { _, value, _ ->
            yValue.text = "Y Sensitivity: ${value.toInt()}%"
        }
        xValue.text = "X Sensitivity: 100%"
        yValue.text = "Y Sensitivity: 100%"

        val button = Button(this).apply {
            text = "Enable Touch Scaling"
            setOnClickListener {
                status.text = if (Shizuku.pingBinder()) {
                    "Shizuku connected. Scaling engine is ready for implementation/testing."
                } else {
                    "Shizuku is not running. Start Shizuku first."
                }
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(xValue)
        root.addView(xSlider)
        root.addView(yValue)
        root.addView(ySlider)
        root.addView(button)

        setContentView(root)
        status.text = if (Shizuku.pingBinder()) "Shizuku detected." else "Shizuku not detected."
    }
}
