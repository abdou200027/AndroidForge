
# TouchScale X/Y

Prototype Android project for independent X/Y touch scaling using Shizuku.

## Important
This version is the UI + Shizuku connectivity prototype. It does NOT claim to
modify raw touchscreen MotionEvents inside Free Fire yet.

Android/One UI does not expose a normal public API that lets an ordinary app
rewrite another app's touchscreen coordinates. A real implementation needs a
privileged input-injection/translation path, which must be tested on the target
Samsung firmware.

## Build
Open this folder in Android Studio and let Gradle sync. Then:

Build > Build APK(s)

Install the generated APK and start Shizuku.

## Target
- Android 11+
- target SDK 35
- Shizuku API 13.1.5
- Designed as a research prototype for Galaxy S24 Ultra / One UI.

## Safety
No macro, auto-aim, or game-file modification is included.
