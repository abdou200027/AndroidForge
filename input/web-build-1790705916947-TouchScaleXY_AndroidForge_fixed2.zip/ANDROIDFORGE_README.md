# TouchScaleXY — AndroidForge build package

Upload this ZIP to AndroidForge.

Recommended build variant: `debug` or `auto`.

AndroidForge URL:
https://professional-x.github.io/AndroidForge/

This package is a prototype. It provides the X/Y controls and Shizuku connectivity,
but it does not yet claim to rewrite Free Fire touchscreen MotionEvents.
